class ProductPage {
  // Click on size dropdown
  clickOnSizeDropDown() {
    cy.get('.dropdown-toggle', { timeout: 10000 }).invoke('css', 'display', 'block').click();
    return this;
  }

  // Click on a specific size option
  clickOnSize() {
    cy.get('a[role="menuitem"][tabindex="0"]').contains('XXS').click({ force: true });

    // cy.get('[data-value="0041010935"] > a', { timeout: 10000 }).click();
    return this;
  }

  // Add item to cart
  addToCart1() { 
    cy.get('.buttons-container > .btn-primary', { timeout: 10000 }).click();
    return this;
  }

  // Get success text after adding to cart
  successText() {
    // Return the Cypress command to retrieve the text of the .modal-title element
    return cy.get('.modal-title', { timeout: 10000 }).invoke('text').then(text => {
      // Log the text to the Cypress command log
      cy.log(text);
      // Return the text to be used in the test
      return text;
    });
  }
  
  

  // Methods for ZipCode Test
  addZipCode() {
    cy.get('class="form-control form-control form-input-postal-code', { timeout: 10000 }).type("12345");
    return this;
  }

  clickOnSearch() {
    cy.get('button.btn.btn-primary.qa-btn-search[name="search"]', { timeout: 10000 }).click();
    return this;
  }

  addressInfo() {
    return cy.get('', { timeout: 10000 }).then($el => $el.text());
  }

  // SizeDetailsTest Methods
  clickOnSizeDetails() {
    cy.get('.qa-size-info > .btn-link', { timeout: 10000 }).click();
    return this;
  }

  clickOnHowToMeasure() {
    cy.get('.qa-howToMeasure-toggle', { timeout: 10000 }).click();
    return this;
  }

  isChartDisplayed() {
    return cy.get('th', { timeout: 10000 }).then($el => $el.is(':visible'));
  }

}

const productPage = new ProductPage();

export default productPage;