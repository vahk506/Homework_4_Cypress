import homePage from '../POM/homePage';
import menPage from '../POM/menPage';
import productPage from '../POM/productPage.JS';


describe('Enter Valid Zip Code Test', () => {
  it('should enter a zip code and validate the address', () => {

    cy.visit('/'); // Adjust the URL to your application's homepage

    // Perform the sequence of actions
    homePage.acceptPrivacyModal();
    // homePage.closeAdMark();
    homePage.hoverOnMenPageDropdown();

    menPage.clickOnViewAll();
    menPage.clickOnProduct();

    productPage.clickOnSizeDropDown();
    productPage.clickOnSize();
    productPage.addZipCode();
    productPage.clickOnSearch();

          // Perform the assertion
          // productPage.addressInfo().should('eq', 'Crossgates Mall - American Eagle & Aerie Store');

  });
 });
  