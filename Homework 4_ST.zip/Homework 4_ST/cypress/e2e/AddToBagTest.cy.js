import HomePage from '../POM/homePage';
import MenPage from '../POM/MenPage';
import productPage from '../POM/ProductPage.JS';

describe('Product Purchase Flow', () => {
  it('should allow a user to add a product to the cart from the men page', () => {
    cy.visit('/'); // Start at the homepage
    HomePage.acceptPrivacyModal()
      // .closeAdMark()
      .hoverOnMenPageDropdown();

    // MenPage.clickOnViewAll()
      MenPage.clickOnProduct();

      productPage
      .clickOnSizeDropDown1()
      .clickOnSize1()
      .addToCart1()
      .successText().should('include', 'Item added successfully');
  });
  });
