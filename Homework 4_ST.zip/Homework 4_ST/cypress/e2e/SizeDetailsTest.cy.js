// const HomePage = require('./POM/homePage');
// const MenPage = require('./POM/menPage');
// const ProductPage = require('./POM/productPage');

import homePage from '../POM/homePage';
import menPage from '../POM/menPage';
import productPage from '../POM/productPage.JS';

describe('Size Details Test', () => {
  it('displays the size chart when how to measure is clicked', () => {
    cy.visit('/'); // Adjust URL to your application's homepage
    

    homePage.acceptPrivacyModal();
    // homePage.closeAdMark();
    homePage.hoverOnMenPageDropdown();

    menPage.clickOnViewAll();
    menPage.clickOnProduct();

    productPage.clickOnSizeDetails();
    productPage.clickOnHowToMeasure();

    // Assertion to check if the size chart is displayed
    productPage.isChartDisplayed().should('be.true');  // Adjust the assertion based on the actual expected result
  });
});