const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    baseUrl :"https://www.ae.com/us/en",
    "viewportWidth": 1800,
  " viewportHeight": 660,
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
  },
  
})

